# Alan Walker Theme
Dark/Light theme with Alan Walker's logo as background
Highly customizable, most colors can be changed using the variables provided
works with transparancy if you prefer that
